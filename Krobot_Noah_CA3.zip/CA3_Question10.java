/**
 *  Name: Noah Krobot
 *  Class Group: SD2B
 */

public class CA3_Question10
{

    public static void main(String[] args) {

    }
}
